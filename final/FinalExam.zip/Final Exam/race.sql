DROP SCHEMA IF EXISTS race;
CREATE SCHEMA IF NOT EXISTS race;
USE race;


-- -----------------------------------------------------
-- Table team
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS team (
    id INT NOT NULL AUTO_INCREMENT,
    name VARCHAR(64) NULL,
    PRIMARY KEY (id)
);


-- -----------------------------------------------------
-- Table cyclist
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS cyclist (
    usac INT NOT NULL,
    first_name VARCHAR(64) NOT NULL,
    last_name VARCHAR(64) NOT NULL,
    team_id INT NOT NULL,
    age INT NULL,
    PRIMARY KEY (usac),
    FOREIGN KEY (team_id)
        REFERENCES team (id)
);


-- -----------------------------------------------------
-- Table city
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS city (
    id INT NOT NULL AUTO_INCREMENT,
    name VARCHAR(64) NOT NULL,
    zip MEDIUMINT(5),
    PRIMARY KEY (id)
);


-- -----------------------------------------------------
-- Table race
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS race (
    id INT NOT NULL AUTO_INCREMENT,
    city_id INT NOT NULL,
    name VARCHAR(64) NOT NULL,
    date DATETIME NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (city_id)
        REFERENCES city (id)
);


-- -----------------------------------------------------
-- Table cyclist_race
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS cyclist_race (
    cyclist_usac INT NOT NULL,
    race_id INT NOT NULL,
    rank INT NOT NULL,
    PRIMARY KEY (cyclist_usac , race_id),
    UNIQUE (race_id , rank),
    FOREIGN KEY (cyclist_usac)
        REFERENCES cyclist (usac),
    FOREIGN KEY (race_id)
        REFERENCES race (id)
);


INSERT INTO team (name) VALUES ('Try to handle bar');
INSERT INTO team (name) VALUES ('Always behind');
INSERT INTO team (name) VALUES ('Sponsors drain');
INSERT INTO team (name) VALUES ('Sore bum');
INSERT INTO team (name) VALUES ('Sweating blood');


INSERT INTO cyclist (team_id, usac, last_name, first_name, age) VALUES (1, 1001, 'Orlando','Myron', 19);
INSERT INTO cyclist (team_id, usac, last_name, first_name, age) VALUES (1, 1002, 'O''Brian','Amy', 24);
INSERT INTO cyclist (team_id, usac, last_name, first_name, age) VALUES (1, 1003, 'Brown','James', 26);
INSERT INTO cyclist (team_id, usac, last_name, first_name, age) VALUES (1, 1004, 'Williams','George', 29);
INSERT INTO cyclist (team_id, usac, last_name, first_name, age) VALUES (1, 1005, 'Farriss','Anne', 30);

INSERT INTO cyclist (team_id, usac, last_name, first_name, age) VALUES (2, 2001, 'Smith','Olette', 21);
INSERT INTO cyclist (team_id, usac, last_name, first_name, age) VALUES (2, 2002, 'Kolmycz','George',22);
INSERT INTO cyclist (team_id, usac, last_name, first_name, age) VALUES (2, 2003, 'Lewis','Rhonda',34);
INSERT INTO cyclist (team_id, usac, last_name, first_name, age) VALUES (2, 2004, 'VanDam','Rhett',23);
INSERT INTO cyclist (team_id, usac, last_name, first_name, age) VALUES (2, 2005, 'Jones','Anne',19);

INSERT INTO cyclist (team_id, usac, last_name, first_name, age) VALUES (3, 3001, 'Lange','John',45);
INSERT INTO cyclist (team_id, usac, last_name, first_name, age) VALUES (3, 3002, 'Williams','Robert',26);
INSERT INTO cyclist (team_id, usac, last_name, first_name, age) VALUES (3, 3003, 'Smith','Jeanine',23);
INSERT INTO cyclist (team_id, usac, last_name, first_name, age) VALUES (3, 3004, 'Diante','Jorge',27);
INSERT INTO cyclist (team_id, usac, last_name, first_name, age) VALUES (3, 3005, 'Wiesenbach','Paul',17);

INSERT INTO cyclist (team_id, usac, last_name, first_name, age) VALUES (4, 4001, 'Smith','George',73);
INSERT INTO cyclist (team_id, usac, last_name, first_name, age) VALUES (4, 4002, 'Genkazi','Leighla',60);
INSERT INTO cyclist (team_id, usac, last_name, first_name, age) VALUES (4, 4003, 'Washington','Rupert',54);

INSERT INTO cyclist (team_id, usac, last_name, first_name, age) VALUES (5, 5001, 'Johnson','Edward',52);
INSERT INTO cyclist (team_id, usac, last_name, first_name, age) VALUES (5, 5002, 'Smythe','Melanie',29);
INSERT INTO cyclist (team_id, usac, last_name, first_name, age) VALUES (5, 5003, 'Brandon','Marie',28);
INSERT INTO cyclist (team_id, usac, last_name, first_name, age) VALUES (5, 5004, 'Saranda','Hermine',12);
INSERT INTO cyclist (team_id, usac, last_name, first_name, age) VALUES (5, 5005, 'Smith','George',33);


INSERT INTO city (name, zip) VALUES ('Flagstaff', '86001');
INSERT INTO city (name, zip) VALUES ('Williams', '86046');
INSERT INTO city (name, zip) VALUES ('Las Vegas', '89101');
INSERT INTO city (name, zip) VALUES ('Sedona', '86336');
INSERT INTO city (name, zip) VALUES ('Goerlitz', NULL);


INSERT INTO race (city_id, `date`, `name`) VALUES (1, 20170125, 'Sunset Crater Challenge');
INSERT INTO race (city_id, `date`, `name`) VALUES (2, 20170305, 'Grand Canyon Memorial');
INSERT INTO race (city_id, `date`, `name`) VALUES (3, 20170514, 'Gambling and Racing');
INSERT INTO race (city_id, `date`, `name`) VALUES (4, 20170623, 'Spiritual Nutcases On The Loose');


INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (1001, 1, 1);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (1002, 1, 2);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (2003, 1, 3);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (2004, 1, 4);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (3001, 1, 5);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (3002, 1, 6);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (3003, 1, 7);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (3004, 1, 8);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (3005, 1, 9);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (4001, 1, 10);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (4002, 1, 11);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (4003, 1, 12);

INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (5001, 2, 1);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (1001, 2, 2);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (5002, 2, 3);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (1002, 2, 4);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (5003, 2, 5);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (1003, 2, 6);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (5004, 2, 7);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (1004, 2, 8);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (5005, 2, 9);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (1005, 2, 10);

INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (2001, 3, 1);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (5001, 3, 2);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (4001, 3, 3);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (4002, 3, 4);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (4003, 3, 5);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (5002, 3, 6);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (2002, 3, 7);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (2003, 3, 8);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (2004, 3, 9);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (5003, 3, 10);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (2005, 3, 11);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (5005, 3, 12);

INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (2001, 4, 1);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (3001, 4, 2);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (4001, 4, 3);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (2002, 4, 4);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (2003, 4, 5);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (2004, 4, 6);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (4002, 4, 7);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (4003, 4, 8);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (3002, 4, 9);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (3003, 4, 10);
INSERT INTO cyclist_race (cyclist_usac, race_id, rank) VALUES (3004, 4, 11);
